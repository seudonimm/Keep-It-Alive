Escapade

Programming and Art by Jawad Usman(@seudonimm)

Music:
Beauty Flow by Kevin MacLeod
Link: https://incompetech.filmmusic.io/song/5025-beauty-flow
License: http://creativecommons.org/licenses/by/4.0/

Ouroboros by Kevin MacLeod
Link: https://incompetech.filmmusic.io/song/4996-ouroboros
License: http://creativecommons.org/licenses/by/4.0/

Cheery Monday by Kevin MacLeod
Link: https://incompetech.filmmusic.io/song/3495-cheery-monday
License: http://creativecommons.org/licenses/by/4.0/


You and your friend have been kept in secret experimental science lab. You have been experimented on so much 
you ascended beyond this mortal realm and obtained omniscience, your friend however turned into a slime. 
Use your newfound powers to create constructs to build paths and protection so your friend can safely exit the 
lab and exact revenge.

Controls:

Left Mouse Button: Build Construct
Right Mouse Button: Destroy Construct

Space Bar: Stop Slime movement

R: restart level
Esc: return to title screen/ exit game

